'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Input } from '@/components/ui/input'
import { Checkbox } from '@/components/ui/checkbox'
import { useToast } from '@/components/ui/use-toast'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

type Permission = 'Read' | 'Write' | 'Delete'
type Role = {
  id: number
  name: string
  permissions: Permission[]
}

const initialRoles: Role[] = [
  { id: 1, name: 'Admin', permissions: ['Read', 'Write', 'Delete'] },
  { id: 2, name: 'Editor', permissions: ['Read', 'Write'] },
  { id: 3, name: 'Viewer', permissions: ['Read'] },
]

export function RoleManagement() {
  const [roles, setRoles] = useState<Role[]>(initialRoles)
  const [newRole, setNewRole] = useState<string>('')
  const { toast } = useToast()

  const addRole = () => {
    if (newRole) {
      setRoles([...roles, { id: roles.length + 1, name: newRole, permissions: [] }])
      setNewRole('')
      toast({
        title: 'Role added',
        description: `${newRole} has been added successfully.`,
      })
    }
  }

  const togglePermission = (roleId: number, permission: Permission) => {
    setRoles(roles.map(role => {
      if (role.id === roleId) {
        const updatedPermissions = role.permissions.includes(permission)
          ? role.permissions.filter(p => p !== permission)
          : [...role.permissions, permission]
        return { ...role, permissions: updatedPermissions }
      }
      return role
    }))
  }

  const deleteRole = (id: number) => {
    setRoles(roles.filter(role => role.id !== id))
    toast({
      title: 'Role deleted',
      description: 'The role has been deleted successfully.',
      variant: 'destructive',
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Role Management</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex space-x-2">
            <Input
              placeholder="New role name"
              value={newRole}
              onChange={(e) => setNewRole(e.target.value)}
              className="flex-1"
            />
            <Button onClick={addRole} className="btn btn-primary">Add Role</Button>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Role</TableHead>
                <TableHead>Read</TableHead>
                <TableHead>Write</TableHead>
                <TableHead>Delete</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {roles.map((role) => (
                <TableRow key={role.id}>
                  <TableCell>{role.name}</TableCell>
                  {(['Read', 'Write', 'Delete'] as Permission[]).map((permission) => (
                    <TableCell key={permission}>
                      <Checkbox
                        checked={role.permissions.includes(permission)}
                        onCheckedChange={() => togglePermission(role.id, permission)}
                      />
                    </TableCell>
                  ))}
                  <TableCell>
                    <Button variant="destructive" onClick={() => deleteRole(role.id)} className="btn btn-ghost">Delete</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}

