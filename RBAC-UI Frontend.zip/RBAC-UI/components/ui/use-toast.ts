import { Toast, ToastActionElement, ToastProps } from "@/components/ui/toast"
import {
  useToast as useToastOriginal,
} from "@/components/ui/use-toast-original"

const useToast = () => {
  const { toast } = useToastOriginal()
  return {
    toast: (props: ToastProps & { action?: ToastActionElement }) => {
      toast(props)
    },
  }
}

export { useToast }
export type { ToastProps, ToastActionElement }

