import { Toast, ToastActionElement, ToastProps } from "@/components/ui/toast"
import {
  useToast as useToastOriginal,
  ToastActionType,
} from "@/components/ui/use-toast-original"

const useToast = () => {
  const { toast } = useToastOriginal()
  return {
    toast: (props: ToastProps & { action?: ToastActionElement }) => {
      toast(props)
    },
  }
}

export { useToast, type ToastActionType }

