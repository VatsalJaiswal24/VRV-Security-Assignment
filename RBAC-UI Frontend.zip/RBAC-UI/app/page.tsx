import { DashboardHeader } from '@/components/dashboard-header'
import { DashboardShell } from '@/components/dashboard-shell'
import { UserManagement } from '@/components/user-management'
import { RoleManagement } from '@/components/role-management'

export default function DashboardPage() {
  return (
    <DashboardShell>
      <DashboardHeader
        heading="RBAC Dashboard"
        text="Manage users, roles, and permissions"
      />
      <div className="grid gap-10">
        <UserManagement />
        <RoleManagement />
      </div>
    </DashboardShell>
  )
}

